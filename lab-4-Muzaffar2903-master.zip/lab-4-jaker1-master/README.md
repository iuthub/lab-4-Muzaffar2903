# Lab 4: Create your Music List

You need to use given repo to create your music list.

### Student Details

- **Student ID**: U1810272
- **Student Name**: Alisher Raimov
- **Section Number**: 001